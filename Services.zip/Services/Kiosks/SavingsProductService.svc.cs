﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;
using SitefinityWebApp.Prototype.SitefinityControllers;
using SitefinityWebApp.Sitefinity.Services.Kiosks.Models;
using Telerik.OpenAccess;
using Telerik.Sitefinity.DynamicModules;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.Taxonomies;
using Telerik.Sitefinity.Taxonomies.Model;
using Telerik.Sitefinity.Utilities.TypeConverters;

namespace SitefinityWebApp.Sitefinity.Services.Kiosks
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "SavingsProductService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select SavingsProductService.svc or SavingsProductService.svc.cs at the Solution Explorer and start debugging.
    [AspNetCompatibilityRequirements(
        RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class SavingsProductService : ISavingsProductService
    {
        public KioskReturnModel<SavingsProductModel> GetSavingsProducts(string cultureName, string kioskId, string datetime)
        {
            if (string.IsNullOrEmpty(datetime))
                datetime = "0";

            var passedDate = DateTime.FromOADate(double.Parse(datetime));

            var manager = TaxonomyManager.GetManager();

            try
            {
                var taxonomy = manager.GetTaxa<FlatTaxon>().SingleOrDefault(t => t.Name == kioskId).Id;
                var dynamicModuleManager = DynamicModuleManager.GetManager();
                var dynamicType = TypeResolutionService.ResolveType(DynamicTypes.SavingsProduct);

                var items = dynamicModuleManager.GetDataItems(dynamicType);
                var myCollection = dynamicModuleManager.GetDataItems(dynamicType)
                    .Where(i =>
                        i.Status == Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Live
                        && i.Visible
                        && i.GetValue<TrackedList<Guid>>("kiosks").Contains(taxonomy)
                        && i.LastModified > passedDate).ToList();
                if (myCollection.Count > 0)
                {
                    myCollection = dynamicModuleManager.GetDataItems(dynamicType)
                    .Where(i =>
                        i.Status == Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Live
                        && i.Visible
                        && i.GetValue<TrackedList<Guid>>("kiosks").Contains(taxonomy)).ToList();
                }

                var returnVal = KioskModelConverter.GetSavingsProductModel(myCollection, cultureName);
                return returnVal;
            }
            catch (Exception ex)
            {
                return KioskModelConverter.GetSavingsProductModel(new List<Telerik.Sitefinity.DynamicModules.Model.DynamicContent>(), cultureName);
            }
        }
    }
}
