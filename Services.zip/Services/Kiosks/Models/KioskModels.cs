﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;
/// using System.Windows.Controls;
using Microsoft.Ajax.Utilities;
using Telerik.Reporting;
using Telerik.Sitefinity.DynamicModules.Model;
using Telerik.Sitefinity.Lifecycle;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.Modules.Libraries;
using Telerik.Sitefinity.RelatedData;
using Image = Telerik.Sitefinity.Libraries.Model.Image;

namespace SitefinityWebApp.Sitefinity.Services.Kiosks.Models
{


    #region Models

    public enum ErrorCodes
    {
        Failed = 0,
        Success = 1,
    }
    [DataContract]
    public class KioskModel
    {
        /// <summary>
        /// number of seconds since epoch 
        /// </summary>
        [DataMember]
        public string Timestamp { get; set; }
    }
    [DataContract]
    public class StatusResponse : KioskModel
    {
        [DataMember]
        public bool Success { get; set; }
        [DataMember]
        public int ErrorCode { get; set; }
        [DataMember]
        public string Description { get; set; }

        public StatusResponse(bool success, ErrorCodes errorcode, string description)
        {
            Success = success;
            ErrorCode = (int) errorcode;
            Description = description;
            Timestamp = DateTime.UtcNow.ToOADate().ToString();
        }
    }

    public class KioskReturnModel<K> : KioskModel
    {
        public List<K> Items { get; set; } 
    }


    public class VideoWallModel
    {
        public string Title { get; set; }

        public string VideoLink { get; set; }

        public int WallId { get; set; }

        public int SortingWeight { get; set; }
    }

    public class QuizScoreModel
    {
        public string Title { get; set; }

        public string Name { get; set; }

        public int QuizId { get; set; }

        public int RightAnswers { get; set; }

        public int Score { get; set; }

        public int CompletionTime { get; set; }

    }

    public class QuizModel
    {
        public string Title { get; set; }

        public string Question { get; set; }

        public string Answer1 { get; set; }

        public string Answer2 { get; set; }

        public string Answer3 { get; set; }

        public string Answer4 { get; set; }

        public int QuizId { get; set; }

        public int SortingWeight { get; set; }

        public int CorrectAnswer { get; set; }

        public int TimeEstimate { get; set; }

    }

    public class SavingsProductModel
    {
        public string Title { get; set; }

        public string OverviewDescription { get; set; }

        public string DetailDescription { get; set; }

        public string OverviewName { get; set; }

        public string DetailName { get; set; }

        public int CategoryId { get; set; }

        public decimal OverviewPrice { get; set; }

        public string DetailPrice { get; set; }

        public List<string> OverviewImage { get; set; }

        public List<string> OverviewImageHover { get; set; }

        public List<string> DetailImage { get; set; }

    }


    public class TabletProductModel
    {
        public string Title { get; set; }

        public string ProductDescription { get; set; }

        public string ProductTable { get; set; }

        public string IntroductionDetail { get; set; }

        public string IntroductionOverview { get; set; }

        public string CTALabel { get; set; }

        public string CTALink { get; set; }

        public int SortingWeight { get; set; }

        public List<string> ProductImage { get; set; }


    }



    public class InteractiveGridModel
    {
        public string Title { get; set; }

        public string VideoURL { get; set; }

        public int GridLocation { get; set; }

        public string TargetPlayer { get; set; }

        public List<string> VideoThumnail { get; set; }


    }


    public class SmarterWayModel
    {
        public string Title { get; set; }

        public string OneCTAText { get; set; }
        public string OneCTAHeading { get; set; }
        public string OneCTACaption { get; set; }
        public string OneCTAImage { get; set; }
        public string OneCTAThumbnail { get; set; }

        public string TwoCTAText { get; set; }
        public string TwoCTAHeading { get; set; }
        public string TwoCTACaption { get; set; }
        public string TwoCTAImage { get; set; }
        public string TwoCTAThumbnail { get; set; }

        public string ThreeCTAText { get; set; }
        public string ThreeCTAHeading { get; set; }
        public string ThreeCTACaption { get; set; }
        public string ThreeCTAImage { get; set; }
        public string ThreeCTAThumbnail { get; set; }

        public string FourCTAText { get; set; }
        public string FourCTAHeading { get; set; }
        public string FourCTACaption { get; set; }
        public string FourCTAImage { get; set; }
        public string FourCTAThumbnail { get; set; }

        
        public string FiveOneCTACaption { get; set; }
        public string FiveOneCTALink { get; set; }
        public string FiveOneCTAImage { get; set; }

        public string FiveTwoCTACaption { get; set; }
        public string FiveTwoCTALink { get; set; }
        public string FiveTwoCTAImage { get; set; }

        public string FiveThreeCTACaption { get; set; }
        public string FiveThreeCTALink { get; set; }
        public string FiveThreeCTAImage { get; set; }

        public string FiveFourCTACaption { get; set; }
        public string FiveFourCTALink { get; set; }
        public string FiveFourCTAImage { get; set; }

        public string FiveFiveCTACaption { get; set; }
        public string FiveFiveCTALink { get; set; }
        public string FiveFiveCTAImage { get; set; }

        public string FiveSixCTACaption { get; set; }
        public string FiveSixCTALink { get; set; }
        public string FiveSixCTAImage { get; set; }


    }

    

    #endregion


    #region Model Factory
    public static class KioskModelConverter
    {

        #region Public functions
        public static KioskReturnModel<VideoWallModel> GetVideoWallServiceModel(List<DynamicContent> myCollection,
            string cultureName)
        {
            var culture = CultureInfo.GetCultureInfo(cultureName);
            var returnVal = new KioskReturnModel<VideoWallModel>() { Timestamp = DateTime.UtcNow.ToOADate().ToString() };
            //var list = myCollection.Select(dynamicContent => GetVideoWallModel(dynamicContent, culture)).ToList();
            var list = new List<VideoWallModel>();
            foreach (var dynamicContent in myCollection)
            {
                var converted = GetVideoWallModel(dynamicContent, culture);
                if (converted != null)
                    list.Add(converted);
            }
            returnVal.Items = list;
            return returnVal;
        }

        public static KioskReturnModel<QuizScoreModel> GetQuizScoreModel(List<DynamicContent> myCollection,
            string cultureName)
        {
            var culture = CultureInfo.GetCultureInfo(cultureName);
            var returnVal = new KioskReturnModel<QuizScoreModel>() { Timestamp = DateTime.UtcNow.ToOADate().ToString() };
            //var list = myCollection.Select(dynamicContent => GetQuizScoreModel(dynamicContent, culture)).ToList();
            var list = new List<QuizScoreModel>();
            foreach (var dynamicContent in myCollection)
            {
                var converted = GetQuizScoreModel(dynamicContent, culture);
                if (converted != null)
                    list.Add(converted);
            }
            returnVal.Items = list;
            return returnVal;
        }

        public static KioskReturnModel<QuizModel> GetQuizModel(List<DynamicContent> myCollection,
            string cultureName)
        {
            var culture = CultureInfo.GetCultureInfo(cultureName);
            var returnVal = new KioskReturnModel<QuizModel>() { Timestamp = DateTime.UtcNow.ToOADate().ToString() };
            //var list = myCollection.Select(dynamicContent => GetQuizModel(dynamicContent, culture)).ToList();
            var list = new List<QuizModel>();
            foreach (var dynamicContent in myCollection)
            {
                var converted = GetQuizModel(dynamicContent, culture);
                if (converted != null)
                    list.Add(converted);
            }
            returnVal.Items = list;
            return returnVal;
        }

        public static KioskReturnModel<SavingsProductModel> GetSavingsProductModel(List<DynamicContent> myCollection,
            string cultureName)
        {
            var culture = CultureInfo.GetCultureInfo(cultureName);
            var returnVal = new KioskReturnModel<SavingsProductModel>() { Timestamp = DateTime.UtcNow.ToOADate().ToString() };
            //var list = myCollection.Select(dynamicContent => GetSavingsProduct(dynamicContent, culture)).ToList();
            var list = new List<SavingsProductModel>();
            foreach (var dynamicContent in myCollection)
            {
                var converted = GetSavingsProduct(dynamicContent, culture);
                if (converted != null)
                    list.Add(converted);
            }
            returnVal.Items = list;
            return returnVal;
        }

        public static KioskReturnModel<TabletProductModel> GetTabletProductModel(List<DynamicContent> myCollection,
            string cultureName)
        {
            var culture = CultureInfo.GetCultureInfo(cultureName);
            var returnVal = new KioskReturnModel<TabletProductModel>() { Timestamp = DateTime.UtcNow.ToOADate().ToString() };
            //var list = myCollection.Select(dynamicContent => GetTabletProduct(dynamicContent, culture)).ToList();
            var list = new List<TabletProductModel>();
            foreach (var dynamicContent in myCollection)
            {
                var converted = GetTabletProduct(dynamicContent, culture);
                if (converted != null)
                    list.Add(converted);
            }
            returnVal.Items = list.OrderBy(model => model.SortingWeight).ToList();
            return returnVal;
        }

        public static KioskReturnModel<SmarterWayModel> GetSmarterWaysModel(List<DynamicContent> myCollection,
            string cultureName)
        {
            var culture = CultureInfo.GetCultureInfo(cultureName);
            var returnVal = new KioskReturnModel<SmarterWayModel>() { Timestamp = DateTime.UtcNow.ToOADate().ToString() };
            //var list = myCollection.Select(dynamicContent => GetTabletProduct(dynamicContent, culture)).ToList();
            var list = new List<SmarterWayModel>();
            if (myCollection.Count>0){
                var converted = GetSmarterWay(myCollection[0], culture);
                if (converted != null)
                    list.Add(converted);
            }
            returnVal.Items = list;
            return returnVal;
        }


        public static KioskReturnModel<InteractiveGridModel> GetInteractiveGridModel(List<DynamicContent> myCollection,
            string cultureName)
        {
            var culture = CultureInfo.GetCultureInfo(cultureName);
            var returnVal = new KioskReturnModel<InteractiveGridModel>() { Timestamp = DateTime.UtcNow.ToOADate().ToString() };
            //var list = myCollection.Select(dynamicContent => GetInteractiveGrid(dynamicContent, culture)).ToList();
            var list = new List<InteractiveGridModel>();
            foreach (var dynamicContent in myCollection)
            {
                var converted = GetInteractiveGrid(dynamicContent, culture);
                if (converted != null)
                    list.Add(converted);
            }
            returnVal.Items = list;
            return returnVal;
        }

        #endregion

        #region Private Functions
        private static VideoWallModel GetVideoWallModel(DynamicContent dynamicContent, CultureInfo culture)
        {
            if (dynamicContent.AvailableCultures.Contains(culture))
            {
                var title = dynamicContent.GetValue<Lstring>("Title").GetString(culture, false);
                var videoLink = dynamicContent.GetValue<Lstring>("VideoLink").GetString(culture, false);
                var wallId = "0";
                var x0 = dynamicContent.GetValue("WallId");
                if (x0!=null)
                    wallId = x0.ToString();
                var sortingWeight = "0";
                var x1 = dynamicContent.GetValue("SortingWeight");
                if (x1!=null)
                    sortingWeight = x1.ToString();
                return new VideoWallModel()
                {
                    Title = title,
                    VideoLink = videoLink,
                    WallId = int.Parse(wallId),
                    SortingWeight = int.Parse(sortingWeight)
                };
            }
            return null;
        }

        private static QuizScoreModel GetQuizScoreModel(DynamicContent dynamicContent, CultureInfo culture)
        {
            if (dynamicContent.AvailableCultures.Contains(culture))
            {
                var title = dynamicContent.GetValue<Lstring>("Title").GetString(culture, false);
                var name = dynamicContent.GetValue<Lstring>("Name").GetString(culture, false);
                var completionTime = "0";
                var x0 = dynamicContent.GetValue("CompletionTime");
                if (x0 !=null)
                    completionTime = x0.ToString();
                var quizId = "0";
                var x1 = dynamicContent.GetValue("QuizId");
                if (x1!=null)
                    quizId = x1.ToString();
                var rightAnswers = "0";
                var x2 = dynamicContent.GetValue("RightAnswers");
                if (x2!=null)
                    rightAnswers = x2.ToString();
                var score = "0";
                var x3 = dynamicContent.GetValue("Score");
                if (x3!=null)
                    score = x3.ToString();
                return new QuizScoreModel()
                {
                    Title = title,
                    Name = name,
                    CompletionTime = int.Parse(completionTime),
                    QuizId = int.Parse(quizId),
                    RightAnswers = int.Parse(rightAnswers),
                    Score = int.Parse(score)
                };
            }
            return null;
        }

        private static QuizModel GetQuizModel(DynamicContent dynamicContent, CultureInfo culture)
        {
            if (dynamicContent.AvailableCultures.Contains(culture))
            {
                var title = dynamicContent.GetValue<Lstring>("Title").GetString(culture, false);
                var question = dynamicContent.GetValue<Lstring>("Question").GetString(culture, false);
                var answer1 = dynamicContent.GetValue<Lstring>("Answer1").GetString(culture, false);
                var answer2 = dynamicContent.GetValue<Lstring>("Answer2").GetString(culture, false);
                var answer3 = dynamicContent.GetValue<Lstring>("Answer3").GetString(culture, false);
                var answer4 = dynamicContent.GetValue<Lstring>("Answer4").GetString(culture, false);
                var quizId = "0";
                var x0 = dynamicContent.GetValue("QuizId");
                if (x0!=null)
                    quizId = x0.ToString();
                var sortingWeight = "0";
                var x1 = dynamicContent.GetValue("SortingWeight");
                if (x1!=null)
                    sortingWeight = x1.ToString();
                var correctAnswer = "0";
                var x2 = dynamicContent.GetValue("CorrectAnswer");
                if (x2!=null)
                    correctAnswer=x2.ToString();
                var timeEstimate = "0";
                var x3 = dynamicContent.GetValue("TimeEstimate");
                if (x3!=null)
                    timeEstimate = x3.ToString();
                return new QuizModel()
                {
                    Title = title,
                    Question = question,
                    Answer1 = answer1,
                    Answer2 = answer2,
                    Answer3 = answer3,
                    Answer4 = answer4,
                    QuizId = int.Parse(quizId),
                    SortingWeight = int.Parse(sortingWeight),
                    CorrectAnswer = int.Parse(correctAnswer),
                    TimeEstimate = int.Parse(timeEstimate)
                };
            }
            return null;
        }

        private static SavingsProductModel GetSavingsProduct(DynamicContent dynamicContent, CultureInfo culture)
        {
            if (dynamicContent.AvailableCultures.Contains(culture))
            {
                var title = dynamicContent.GetValue<Lstring>("Title").GetString(culture, false);
                var overviewdescription = dynamicContent.GetValue<Lstring>("OverviewDescription")
                    .GetString(culture, false);
                var detaildescription = dynamicContent.GetValue<Lstring>("DetailDescription").GetString(culture, false);
                var overviewname = dynamicContent.GetValue<Lstring>("OverviewName").GetString(culture, false);
                var detailname = dynamicContent.GetValue<Lstring>("DetailName").GetString(culture, false);
                var categoryId = "0";
                var x0 = dynamicContent.GetValue("CategoryId");
                if (x0!=null)
                    categoryId = x0.ToString();
                var overviewprice = "0";
                var x1 = dynamicContent.GetValue("OverviewPrice");
                if (x1 != null)
                    overviewprice = x1.ToString();
                var detailprice = dynamicContent.GetValue<Lstring>("DetailPrice").GetString(culture, false);
                var overviewImageCollection = dynamicContent.GetRelatedItems<Image>("OverviewImage");
                var overviewImages = new List<string>();
                foreach (var image in overviewImageCollection)
                {
                    overviewImages.Add(image.Url);
                }


                var overviewImageHoverCollection = dynamicContent.GetRelatedItems<Image>("OverviewImageHover");
                var overviewImageHovers = new List<string>();
                foreach (var image in overviewImageHoverCollection)
                {
                    overviewImageHovers.Add(image.Url);
                }


                var detailImageCollection = dynamicContent.GetRelatedItems<Image>("DetailImage");
                var detailImages = new List<string>();
                foreach (var image in detailImageCollection)
                {
                    detailImages.Add(image.Url);
                }


                return new SavingsProductModel()
                {
                    Title = title,
                    OverviewDescription = overviewdescription,
                    DetailDescription = detaildescription,
                    OverviewName = overviewname,
                    DetailName = detailname,
                    CategoryId = int.Parse(categoryId),
                    OverviewPrice = decimal.Parse(overviewprice),
                    DetailPrice = detailprice,
                    OverviewImage = overviewImages,
                    OverviewImageHover = overviewImageHovers,
                    DetailImage = detailImages
                };
            }
            else
            {
                return null;
            }
        }

        private static TabletProductModel GetTabletProduct(DynamicContent dynamicContent, CultureInfo culture)
        {
            if (dynamicContent.AvailableCultures.Contains(culture))
            {
                var title = dynamicContent.GetValue<Lstring>("Title").GetString(culture, false);
                var productdescription = dynamicContent.GetValue<Lstring>("ProductDescription")
                    .GetString(culture, false);
                var producttable = dynamicContent.GetValue<Lstring>("ProductTable").GetString(culture, false);
                var introductiondetail = dynamicContent.GetValue<Lstring>("IntroductionDetail")
                    .GetString(culture, false);
                var introductionoverview = dynamicContent.GetValue<Lstring>("IntroductOverview")
                    .GetString(culture, false);
                var ctalabel = dynamicContent.GetValue<Lstring>("CTALabel").GetString(culture, false);
                var ctalink = dynamicContent.GetValue<Lstring>("CTALink").GetString(culture, false);
                var sortingweight = "0";
                var x0 = dynamicContent.GetValue("SortingWeight");
                if (x0!=null)
                    sortingweight = x0.ToString();

                var productImagesCollection = dynamicContent.GetRelatedItems<Image>("ProductImage");
                var productImages = new List<string>();
                foreach (var image in productImagesCollection)
                {
                    productImages.Add(image.Url);
                }

                return new TabletProductModel()
                {
                    Title = title,
                    ProductDescription = productdescription,
                    ProductTable = producttable,
                    IntroductionDetail = introductiondetail,
                    IntroductionOverview = introductionoverview,
                    CTALabel = ctalabel,
                    CTALink = ctalink,
                    SortingWeight = int.Parse(sortingweight),
                    ProductImage = productImages
                };
            }
            return null;
        }

        private static SmarterWayModel GetSmarterWay(DynamicContent dynamicContent, CultureInfo culture)
        {
            if (dynamicContent.AvailableCultures.Contains(culture))
            {
                var title = dynamicContent.GetValue<Lstring>("Title").GetString(culture, false);

                var onectatext = dynamicContent.GetValue<Lstring>("OneCTAText").GetString(culture, false);
                var onectacaption = dynamicContent.GetValue<Lstring>("OneCTACaption").GetString(culture, false);
                var onectaheading = dynamicContent.GetValue<Lstring>("OneCTAHeading").GetString(culture, false);
                var imagesCollection = dynamicContent.GetRelatedItems<Image>("OneCTAImage");
                var onectaimage = "";
                foreach (var image in imagesCollection)
                {
                    onectaimage = image.Url;
                }
                imagesCollection = dynamicContent.GetRelatedItems<Image>("OneCTAThumbnail");
                var onectathumbnail = "";
                foreach (var image in imagesCollection)
                {
                    onectathumbnail = image.Url;
                }

                var twoctatext = dynamicContent.GetValue<Lstring>("TwoCTAText").GetString(culture, false);
                var twoctacaption = dynamicContent.GetValue<Lstring>("TwoCTACaption").GetString(culture, false);
                var twoctaheading = dynamicContent.GetValue<Lstring>("TwoCTAHeading").GetString(culture, false);
                imagesCollection = dynamicContent.GetRelatedItems<Image>("TwoCTAImage");
                var twoctaimage = "";
                foreach (var image in imagesCollection)
                {
                    twoctaimage = image.Url;
                }
                imagesCollection = dynamicContent.GetRelatedItems<Image>("TwoCTAThumbnail");
                var twoctathumbnail = "";
                foreach (var image in imagesCollection)
                {
                    twoctathumbnail = image.Url;
                }


                var threectatext = dynamicContent.GetValue<Lstring>("ThreeCTAText").GetString(culture, false);
                var threectacaption = dynamicContent.GetValue<Lstring>("ThreeCTACaption").GetString(culture, false);
                var threectaheading = dynamicContent.GetValue<Lstring>("ThreeCTAHeading").GetString(culture, false);
                imagesCollection = dynamicContent.GetRelatedItems<Image>("ThreeCTAImage");
                var threectaimage = "";
                foreach (var image in imagesCollection)
                {
                    threectaimage = image.Url;
                }
                imagesCollection = dynamicContent.GetRelatedItems<Image>("ThreeCTAThumbnail");
                var threectathumbnail = "";
                foreach (var image in imagesCollection)
                {
                    threectathumbnail = image.Url;
                }



                var fourctatext = dynamicContent.GetValue<Lstring>("FourCTAText").GetString(culture, false);
                var fourctacaption = dynamicContent.GetValue<Lstring>("FourCTACaption").GetString(culture, false);
                var fourctaheading = dynamicContent.GetValue<Lstring>("FourCTAHeading").GetString(culture, false);
                imagesCollection = dynamicContent.GetRelatedItems<Image>("FourCTAImage");
                var fourctaimage = "";
                foreach (var image in imagesCollection)
                {
                    fourctaimage = image.Url;
                }
                imagesCollection = dynamicContent.GetRelatedItems<Image>("FourCTAThumbnail");
                var fourctathumbnail = "";
                foreach (var image in imagesCollection)
                {
                    fourctathumbnail = image.Url;
                }



                var fiveonectacaption = dynamicContent.GetValue<Lstring>("FiveOneCTACaption").GetString(culture, false);
                var fiveonectalink = dynamicContent.GetValue<Lstring>("FiveOneCTALink").GetString(culture, false);
                imagesCollection = dynamicContent.GetRelatedItems<Image>("FiveOneCTAImage");
                var fiveonectaimage = "";
                foreach (var image in imagesCollection)
                {
                    fiveonectaimage = image.Url;
                }

                var fivetwoctacaption = dynamicContent.GetValue<Lstring>("FiveTwoCTACaption").GetString(culture, false);
                var fivetwoctalink = dynamicContent.GetValue<Lstring>("FiveTwoCTALink").GetString(culture, false);
                imagesCollection = dynamicContent.GetRelatedItems<Image>("FiveTwoCTAImage");
                var fivetwoctaimage = "";
                foreach (var image in imagesCollection)
                {
                    fivetwoctaimage = image.Url;
                }

                var fivethreectacaption = dynamicContent.GetValue<Lstring>("FiveThreeCTACaption").GetString(culture, false);
                var fivethreectalink = dynamicContent.GetValue<Lstring>("FiveThreeCTALink").GetString(culture, false);
                imagesCollection = dynamicContent.GetRelatedItems<Image>("FiveThreeCTAImage");
                var fivethreectaimage = "";
                foreach (var image in imagesCollection)
                {
                    fivethreectaimage = image.Url;
                }

                var fivefourctacaption = dynamicContent.GetValue<Lstring>("FiveFourCTACaption").GetString(culture, false);
                var fivefourctalink = dynamicContent.GetValue<Lstring>("FiveFourCTALink").GetString(culture, false);
                imagesCollection = dynamicContent.GetRelatedItems<Image>("FiveFourCTAImage");
                var fivefourctaimage = "";
                foreach (var image in imagesCollection)
                {
                    fivefourctaimage = image.Url;
                }

                var fivefivectacaption = dynamicContent.GetValue<Lstring>("FiveFiveCTACaption").GetString(culture, false);
                var fivefivectalink = dynamicContent.GetValue<Lstring>("FiveFiveCTALink").GetString(culture, false);
                imagesCollection = dynamicContent.GetRelatedItems<Image>("FiveFiveCTAImage");
                var fivefivectaimage = "";
                foreach (var image in imagesCollection)
                {
                    fivefivectaimage = image.Url;
                }


                var fivesixctacaption = dynamicContent.GetValue<Lstring>("FiveSixCTACaption").GetString(culture, false);
                var fivesixctalink = dynamicContent.GetValue<Lstring>("FiveSixCTALink").GetString(culture, false);
                imagesCollection = dynamicContent.GetRelatedItems<Image>("FiveSixCTAImage");
                var fivesixctaimage = "";
                foreach (var image in imagesCollection)
                {
                    fivesixctaimage = image.Url;
                }


                return new SmarterWayModel()
                {
                    Title = title,
                    OneCTACaption = onectacaption,
                    OneCTAHeading = onectaheading,
                    OneCTAText = onectatext,
                    OneCTAImage = onectaimage,
                    OneCTAThumbnail = onectathumbnail,

                    TwoCTACaption = twoctacaption,
                    TwoCTAHeading = twoctaheading,
                    TwoCTAText = twoctatext,
                    TwoCTAImage = twoctaimage,
                    TwoCTAThumbnail = twoctathumbnail,

                    ThreeCTACaption = threectacaption,
                    ThreeCTAHeading = threectaheading,
                    ThreeCTAText = threectatext,
                    ThreeCTAImage = threectaimage,
                    ThreeCTAThumbnail = threectathumbnail,

                    FourCTACaption = fourctacaption,
                    FourCTAHeading = fourctaheading,
                    FourCTAText = fourctatext,
                    FourCTAImage = fourctaimage,
                    FourCTAThumbnail = fourctathumbnail,

                    FiveOneCTACaption = fiveonectacaption,
                    FiveOneCTALink = fiveonectalink,
                    FiveOneCTAImage = fiveonectaimage,

                    FiveTwoCTACaption = fivetwoctacaption,
                    FiveTwoCTALink = fivetwoctalink,
                    FiveTwoCTAImage = fivetwoctaimage,

                    FiveThreeCTACaption = fivethreectacaption,
                    FiveThreeCTALink = fivethreectalink,
                    FiveThreeCTAImage = fivethreectaimage,

                    FiveFourCTACaption = fivefourctacaption,
                    FiveFourCTALink = fivefourctalink,
                    FiveFourCTAImage = fivefourctaimage,

                    FiveFiveCTACaption = fivefivectacaption,
                    FiveFiveCTALink = fivefivectalink,
                    FiveFiveCTAImage = fivefivectaimage,

                    FiveSixCTACaption = fivesixctacaption,
                    FiveSixCTALink = fivesixctalink,
                    FiveSixCTAImage = fivesixctaimage,
                };
            }
            return null;
        }

        private static InteractiveGridModel GetInteractiveGrid(DynamicContent dynamicContent, CultureInfo culture)
        {
            if (dynamicContent.AvailableCultures.Contains(culture))
            {
                var title = dynamicContent.GetValue<Lstring>("Title").GetString(culture, false);
                var videoURL = dynamicContent.GetValue<Lstring>("GridVideo").GetString(culture, false);
                var gridlocation = "0";
                var x0 = dynamicContent.GetValue("GridLocation");
                if (x0!=null)
                    gridlocation = x0.ToString();
                var targetPlayer = dynamicContent.GetValue<ChoiceOption>("TargetPlayer");
                var targetPlayerValue = targetPlayer.PersistedValue;

                var videothumnailcollection = dynamicContent.GetRelatedItems<Image>("VideoThumbnail");
                var videoThumnails = new List<string>();
                foreach (var image in videothumnailcollection)
                {
                    videoThumnails.Add(image.Url);
                }

                return new InteractiveGridModel()
                {
                    Title = title,
                    VideoURL = videoURL,
                    TargetPlayer = targetPlayerValue,
                    GridLocation = int.Parse(gridlocation),
                    VideoThumnail = videoThumnails
                };
            }
            return null;
        }

        #endregion
    }
    #endregion
}

