﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;
using SitefinityWebApp.Prototype.SitefinityControllers;
using SitefinityWebApp.Sitefinity.Services.Kiosks.Models;
using Telerik.OpenAccess;
using Telerik.Sitefinity.DynamicModules;
using Telerik.Sitefinity.DynamicModules.Model;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.Taxonomies;
using Telerik.Sitefinity.Taxonomies.Model;
using Telerik.Sitefinity.Utilities.TypeConverters;

namespace SitefinityWebApp.Sitefinity.Services.Kiosks
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "QuizService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select QuizService.svc or QuizService.svc.cs at the Solution Explorer and start debugging.
    [AspNetCompatibilityRequirements(
        RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class QuizService : IQuizService
    {
        public KioskReturnModel<QuizModel> GetQuizes(string cultureName, string kioskId, string quizId, string datetime)
        {
            if (string.IsNullOrEmpty(datetime))
                datetime = "0";
            var passedDate = DateTime.FromOADate(double.Parse(datetime));

            var manager = TaxonomyManager.GetManager();

            try
            {
                var taxonomy = manager.GetTaxa<FlatTaxon>().SingleOrDefault(t => t.Name == kioskId).Id;
                var dynamicModuleManager = DynamicModuleManager.GetManager();
                var dynamicType = TypeResolutionService.ResolveType(DynamicTypes.Quiz);

                var myCollection = dynamicModuleManager.GetDataItems(dynamicType)
                    .Where(i =>
                        i.Status == Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Live
                        && i.Visible
                        && i.GetValue<TrackedList<Guid>>("kiosks").Contains(taxonomy)
                        && i.LastModified > passedDate).ToList();

                if (myCollection.Count > 0)
                {
                    myCollection = dynamicModuleManager.GetDataItems(dynamicType)
                    .Where(i =>
                        i.Status == Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Live
                        && i.Visible
                        && i.GetValue<TrackedList<Guid>>("kiosks").Contains(taxonomy)).ToList();
                }

                var newCollection = new List<DynamicContent>();
                foreach (var dynamicContent in myCollection)
                {
                    if (dynamicContent.GetValue("QuizId").ToString() == quizId)
                        newCollection.Add(dynamicContent);
                }
                var returnVal = KioskModelConverter.GetQuizModel(newCollection, cultureName);
                return returnVal;
            }
            catch (Exception ex)
            {
                return KioskModelConverter.GetQuizModel(new List<Telerik.Sitefinity.DynamicModules.Model.DynamicContent>(), cultureName);
            }
        }
    }
}
