﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using SitefinityWebApp.Prototype.SitefinityControllers;
using SitefinityWebApp.Sitefinity.Services.Kiosks.Models;
using System.ServiceModel.Activation;
using Telerik.OpenAccess;
using Telerik.Sitefinity.DynamicModules;
using Telerik.Sitefinity.Fluent.Content;
using Telerik.Sitefinity.GeoLocations.Model;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.Taxonomies;
using Telerik.Sitefinity.Taxonomies.Model;
using Telerik.Sitefinity.Utilities.TypeConverters;

namespace SitefinityWebApp.Sitefinity.Services.Kiosks
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "VideoWallService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select VideoWallService.svc or VideoWallService.svc.cs at the Solution Explorer and start debugging.
    [AspNetCompatibilityRequirements(
        RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class VideoWallService : IVideoWallService
    {
        public KioskReturnModel<VideoWallModel> GetVideos(string cultureName, string kioskId, string datetime)
        {
            if (string.IsNullOrEmpty(datetime))
                datetime = "0";
            var passedDate = DateTime.FromOADate(double.Parse(datetime));

            var manager = TaxonomyManager.GetManager();

            try
            {
                var taxonomy = manager.GetTaxa<FlatTaxon>().SingleOrDefault(t => t.Name == kioskId).Id;
                var dynamicModuleManager = DynamicModuleManager.GetManager();
                var dynamicType = TypeResolutionService.ResolveType(DynamicTypes.VideoWall);

                var myCollection = dynamicModuleManager.GetDataItems(dynamicType)
                    .Where(i =>
                        i.Status == Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Live
                        && i.Visible
                        && i.GetValue<TrackedList<Guid>>("kiosks").Contains(taxonomy)
                        && i.LastModified > passedDate).ToList();
                if (myCollection.Count > 0)
                {
                    myCollection = dynamicModuleManager.GetDataItems(dynamicType)
                    .Where(i =>
                        i.Status == Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Live
                        && i.Visible
                        && i.GetValue<TrackedList<Guid>>("kiosks").Contains(taxonomy)).ToList();
                }
                var returnVal = KioskModelConverter.GetVideoWallServiceModel(myCollection, cultureName);
                return returnVal;
            }
            catch (Exception ex)
            {
                return KioskModelConverter.GetVideoWallServiceModel(new List<Telerik.Sitefinity.DynamicModules.Model.DynamicContent>(), cultureName);
            }
        }
    }
}
