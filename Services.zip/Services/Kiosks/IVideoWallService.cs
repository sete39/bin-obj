﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using SitefinityWebApp.Sitefinity.Services.Kiosks.Models;

namespace SitefinityWebApp.Sitefinity.Services.Kiosks
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IVideoWallService" in both code and config file together.
    [ServiceContract]
    public interface IVideoWallService
    {
        [WebGet(UriTemplate = "{cultureName}/{kioskId}/fetch?timestamp={datetime}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        KioskReturnModel<VideoWallModel> GetVideos(string cultureName, string kioskId, string datetime);
    }
}
