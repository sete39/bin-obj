﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.ServiceModel.Activation;
using System.Text.RegularExpressions;
using System.Threading;
using SitefinityWebApp.Prototype.SitefinityControllers;
using SitefinityWebApp.Sitefinity.Services.Kiosks.Models;
using Telerik.OpenAccess;
using Telerik.Sitefinity;
using Telerik.Sitefinity.DynamicModules;
using Telerik.Sitefinity.DynamicModules.Model;
using Telerik.Sitefinity.Lifecycle;
using Telerik.Sitefinity.Model;
using Telerik.Sitefinity.Taxonomies;
using Telerik.Sitefinity.Taxonomies.Model;
using Telerik.Sitefinity.Utilities.TypeConverters;
using Telerik.Sitefinity.Security;

namespace SitefinityWebApp.Sitefinity.Services.Kiosks
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "QuizScoreService" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select QuizScoreService.svc or QuizScoreService.svc.cs at the Solution Explorer and start debugging.
    [AspNetCompatibilityRequirements(
        RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    public class QuizScoreService : IQuizScoreService
    {

        public KioskReturnModel<QuizScoreModel> GetScores(string cultureName, string kioskId, string quizId, string count)
        {
            if (string.IsNullOrEmpty(count))
                count = "10";
            var quizIdint = int.Parse(quizId);
            var manager = TaxonomyManager.GetManager();

            try
            {
                var taxonomy = manager.GetTaxa<FlatTaxon>().SingleOrDefault(t => t.Name == kioskId).Id;
                var dynamicModuleManager = DynamicModuleManager.GetManager();
                var dynamicType = TypeResolutionService.ResolveType(DynamicTypes.QuizScore);

                var myCollection = dynamicModuleManager.GetDataItems(dynamicType)
                    .Where(i =>
                        i.Status == Telerik.Sitefinity.GenericContent.Model.ContentLifecycleStatus.Live
                        && i.Visible
                        && i.GetValue<TrackedList<Guid>>("kiosks").Contains(taxonomy))
                        .OrderByDescending(content => content.LastModified).ToList();
                var newCollection = new List<DynamicContent>();
                foreach (var dynamicContent in myCollection)
                {
                    if (dynamicContent.GetValue("QuizId").ToString() == quizId)
                        newCollection.Add(dynamicContent);
                }

                var returnVal = KioskModelConverter.GetQuizScoreModel(newCollection, cultureName);
                returnVal.Items =
                    returnVal.Items.OrderByDescending(model => model.Score)
                        .ThenByDescending(model => model.RightAnswers)
                        .Take(int.Parse(count)).ToList();
                return returnVal;
            }
            catch (Exception ex)
            {
                return KioskModelConverter.GetQuizScoreModel(new List<Telerik.Sitefinity.DynamicModules.Model.DynamicContent>(), cultureName);
            }
        }
    }
}
