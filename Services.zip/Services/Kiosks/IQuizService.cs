﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using SitefinityWebApp.Sitefinity.Services.Kiosks.Models;

namespace SitefinityWebApp.Sitefinity.Services.Kiosks
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IQuizService" in both code and config file together.
    [ServiceContract]
    public interface IQuizService
    {
        [WebGet(UriTemplate = "{cultureName}/{kioskId}/fetch?quizid={quizId}&timestamp={datetime}", ResponseFormat = WebMessageFormat.Json)]
        [OperationContract]
        KioskReturnModel<QuizModel> GetQuizes(string cultureName, string kioskId, string quizId, string datetime);
    }
}
